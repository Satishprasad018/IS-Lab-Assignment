print("Hello World")
def decrypt_substitution(ciphertext,key):
  plaintext=""
  for char in ciphertext:
    if char.isalpha():
        if char.isupper():
            decrypted_char_char = key[char]
        else:
            decrypted_char=key[char.upper()].upper()
            plaintext+=decrypted_char
    else:
        plaintext+=char
        return plaintext
ciphertext="ABI"
key={
        'A':'L',
        'B':'H',
        'C':'I'
        
        }
plaintext = decrypt_substitution(ciphertext,key)
print("decrypted text",plaintext)              
    
